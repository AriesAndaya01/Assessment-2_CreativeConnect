<?php
require_once __DIR__ . '/includes/db.php';
if (user()) { header('Location: dashboard.php'); exit; }
$err = ''; $v = ['name' => '', 'email' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['name'] = trim($_POST['name'] ?? '');
    $v['email'] = strtolower(trim($_POST['email'] ?? ''));
    $pw = $_POST['password'] ?? ''; $pw2 = $_POST['password2'] ?? '';
    try {
        if (!csrf_ok()) throw new Exception('Session expired. Reload and try again.');
        if (mb_strlen($v['name']) < 2 || mb_strlen($v['name']) > 100) throw new Exception('Enter your full name (2 to 100 characters).');
        if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || strlen($v['email']) > 150) throw new Exception('Enter a valid email address.');
        if (strlen($pw) < 8) throw new Exception('Password must be at least 8 characters.');
        if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) throw new Exception('Password needs at least one letter and one number.');
        if ($pw !== $pw2) throw new Exception('The two passwords do not match.');
        // Public sign-up always creates a CLIENT. Staff and admin accounts are created by an admin only.
        db()->prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)')
            ->execute([$v['name'], $v['email'], password_hash($pw, PASSWORD_DEFAULT), 'client']);
        $id = (int)db()->lastInsertId();
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $id, 'name' => $v['name'], 'email' => $v['email'], 'role' => 'client'];
        log_action('signup', $v['email']);
        flash('Welcome to CreativeConnect. Your account is ready.');
        header('Location: dashboard.php'); exit;
    } catch (PDOException $e) {
        $err = $e->getCode() === '23000' ? 'An account with that email already exists. Log in instead.' : 'Database not ready. Run setup.php first.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}
page_top('Sign up'); ?>
<div class="narrow"><h1>Create your account</h1>
<p class="muted">Sign up to submit project requests and track their progress.</p>
<?php if ($err): ?><p class="notice err" role="alert"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="contact-form"><input type="hidden" name="csrf" value="<?= csrf() ?>">
<div class="form-field"><label for="name">Full name</label><input id="name" name="name" required minlength="2" maxlength="100" autocomplete="name" value="<?= e($v['name']) ?>"></div>
<div class="form-field"><label for="email">Email</label><input id="email" name="email" type="email" required maxlength="150" autocomplete="email" value="<?= e($v['email']) ?>"></div>
<div class="form-field"><label for="password">Password</label><input id="password" name="password" type="password" required minlength="8" autocomplete="new-password" aria-describedby="pw-hint"><small id="pw-hint" class="muted">At least 8 characters, with a letter and a number.</small></div>
<div class="form-field"><label for="password2">Confirm password</label><input id="password2" name="password2" type="password" required minlength="8" autocomplete="new-password"></div>
<button class="btn btn-primary" type="submit">Create account</button></form>
<p class="muted" style="margin-top:1rem">Already have an account? <a href="login.php">Log in</a></p></div>
<?php page_bottom();
